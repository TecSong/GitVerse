# GitVerse
## first step: install dependencies
 `npm i`